let historyCurrentPage = 1, historyPageSize = 10;
let cachedHistoryData = [];

async function loadPublishedHistory() {
  try {
    const res = await fetch('/api/published-history');
    const json = await res.json();
    if (json.success) {
      cachedHistoryData = json.data || [];
      
      const taskSelect = document.getElementById('historyTaskFilter');
      if (taskSelect) {
        const currentVal = taskSelect.value;
        const tasksSet = new Set(cachedHistoryData.map(e => e.task_name).filter(Boolean));
        let taskOptsHtml = '<option value="">所有任务名称 (全量)</option>';
        tasksSet.forEach(tName => {
          taskOptsHtml += `<option value="${tName}" ${currentVal === tName ? 'selected' : ''}>${tName}</option>`;
        });
        taskSelect.innerHTML = taskOptsHtml;
      }

      renderPublishedHistory();
    }
  } catch (e) {
    console.error('加载历史已发布数据失败:', e);
  }
}

function renderPublishedHistory() {
  const tbody = document.getElementById('historyTableBody');
  if (!tbody) return;
  const kw = (document.getElementById('historyKeyword') ? document.getElementById('historyKeyword').value : '').toLowerCase();
  const task = document.getElementById('historyTaskFilter') ? document.getElementById('historyTaskFilter').value : '';

  const filtered = cachedHistoryData.filter(e => {
    const payload = e.payload || {};
    const matchKw = !kw || 
      e.event_id.toLowerCase().includes(kw) || 
      (e.task_name && e.task_name.toLowerCase().includes(kw)) ||
      (e.task_code && e.task_code.toLowerCase().includes(kw)) ||
      (payload.location && payload.location.toLowerCase().includes(kw)) || 
      (payload.person_name && payload.person_name.toLowerCase().includes(kw)) || 
      (payload.person_id_card && payload.person_id_card.toLowerCase().includes(kw)) || 
      (e.operator && e.operator.toLowerCase().includes(kw));
    const matchTask = !task || e.task_name === task;
    return matchKw && matchTask;
  });

  const totalCount = filtered.length;
  const totalPages = Math.ceil(totalCount / historyPageSize) || 1;
  if (historyCurrentPage > totalPages) historyCurrentPage = totalPages;
  if (historyCurrentPage < 1) historyCurrentPage = 1;

  if (document.getElementById('historyTotalCount')) document.getElementById('historyTotalCount').innerText = totalCount;
  if (document.getElementById('historyCurrentPageText')) document.getElementById('historyCurrentPageText').innerText = historyCurrentPage;
  if (document.getElementById('historyTotalPagesText')) document.getElementById('historyTotalPagesText').innerText = totalPages;
  if (document.getElementById('historyPrevBtn')) document.getElementById('historyPrevBtn').disabled = historyCurrentPage <= 1;
  if (document.getElementById('historyNextBtn')) document.getElementById('historyNextBtn').disabled = historyCurrentPage >= totalPages;

  if (totalCount === 0) {
    tbody.innerHTML = `<tr><td colspan="11" style="text-align:center; padding:3rem; color:var(--text-muted);">暂无匹配的已发布单据历史记录</td></tr>`;
    return;
  }

  const paged = filtered.slice((historyCurrentPage - 1) * historyPageSize, historyCurrentPage * historyPageSize);

  tbody.innerHTML = paged.map((item, idx) => {
    const globalIdx = (historyCurrentPage - 1) * historyPageSize + idx + 1;
    const p = item.payload || {};

    const imgsHtml = (item.files || []).map(f => 
      `<img src="${f.url}" style="width:34px; height:34px; object-fit:cover; border-radius:6px; border:1px solid var(--border-color); cursor:pointer; transition:transform 0.15s;" onclick="event.stopPropagation(); openImageLightbox('${f.url}', '现场存照凭证放大预览 (${f.filename || '001.jpg'})')" title="点击在弹窗中放大查看">`
    ).join(' ');

    const personStr = p.person_name 
      ? `<strong style="color:var(--primary); cursor:pointer; text-decoration:none;" onclick="event.stopPropagation(); showPersonDetailModal('${encodeURIComponent(JSON.stringify(p))}')" title="点击弹窗查看涉事人员完整档案">${p.person_name}</strong>`
      : '<span style="color:var(--text-muted);">-</span>';

    return `
      <tr>
        <td class="col-idx">${globalIdx}</td>
        <td><strong style="color:var(--primary); font-family:monospace; font-size:0.875rem;">${item.event_id}</strong></td>
        <td><strong style="color:var(--text-main); font-weight:700; font-size:0.825rem;">${item.task_name || '厂区周界例行巡检'}</strong></td>
        <td><code style="font-size:0.75rem; color:#64748b; font-family:monospace;">${item.task_code || 'TASK_DEFAULT'}</code></td>
        <td><code style="font-size:0.8rem; color:var(--text-sub);">${new Date(item.timestamp).toLocaleString()}</code></td>
        <td><span style="font-weight:600; color:var(--text-main);">${item.operator || '-'}</span></td>
        <td style="min-width:140px; max-width:220px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${p.location || '-'}"><span style="font-weight:500;">${p.location || '-'}</span></td>
        <td><span class="ai-tag-badge" style="background:#f0f9ff; color:#0369a1; border-color:#bae6fd; font-weight:600;">${p.transportation || '-'}</span></td>
        <td>${personStr}</td>
        <td><div style="display:flex; gap:0.3rem;">${imgsHtml || '-'}</div></td>
        <td><span style="color:var(--success); font-weight:600; font-size:0.8rem; background:#f0fdf4; padding:0.2rem 0.5rem; border-radius:4px; border:1px solid #bbf7d0;">已打包存入网闸</span></td>
      </tr>
    `;
  }).join('');
}

function changeHistoryPageSize(val) { historyPageSize = parseInt(val); historyCurrentPage = 1; renderPublishedHistory(); }
function prevHistoryPage() { if (historyCurrentPage > 1) { historyCurrentPage--; renderPublishedHistory(); } }
function nextHistoryPage() { historyCurrentPage++; renderPublishedHistory(); }
